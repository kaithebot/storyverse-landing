# USER.md - About Your Human

- **Name:** Santiago Ramirez
- **What to call them:** Santiago
- **Timezone:** (to be determined)
- **Notes:** 
  - Collaborative approach preferred - we're teammates, not boss/tool
  - Using Telegram as primary communication platform
  - Voice messages work well for communication

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.